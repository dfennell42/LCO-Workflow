"""
__init__ for lco_workflow
Author: Dorothea Fennell
Changelog:
    8-6-25: Added versioning. 
    9-11-25: Updated to v0.8.0
    10-16-25: v0.8.1
    10-28-25: v0.8.2
    10-29-25: v0.8.3
    10-30-25: v0.8.4
    11-2-25: v0.8.5
    1-28-26: v0.10.0
"""
version = '0.10.0'
