"""
Extract electronic and structural decriptors for ML
Author: Dorothea Fennell
Changelog:
    7-9-25: Created, comments added
    7-11-25: Added funcs for electronegativity, band center, bond lengths and formation energy.
    7-14-25: Added funcs for t2g/e_g resolved dos and getting pdos data. Set most funcs to return pandas series and began extract.
    7-16-25: Finished extract function and finished script.
    8-20-25: Added function to extract ionization energy and polarizability. Added ability to get difference between O2p band center and conduction band minimum
    11-7-25: Updating integration
    12-5-25: Added func to extract Eovac from binary metal oxides
    1-27-26: Added func to get avg intensity of occupied PDOS regions for LCE
    2-3-26: Added std. reduction potential descriptor. Added avg_ion_e to function getting ionization energy. Added section to calculate
            average band centers & widths for LCE.Also added section to get calculated # of electrons for new potential descriptor. 
            Added func to calculate electron and avg pdos intensity weighted descriptors. 
"""
#import modules
from pymatgen.io.vasp import Vasprun
from pymatgen.electronic_structure.core import OrbitalType, Spin
import os
from ase.io import read
from ase.formula import Formula
import numpy as np
import pandas as pd
from scipy.integrate import simpson 
#define functions
def read_file(r_dir, file):
    '''Reads given file in directory and returns list of lines'''
    F = open(os.path.join(r_dir,file),'r')
    lines = F.readlines()
    F.close
    return lines

def sort_mods(data):
    num = data.split('_')[1]
    return int(num)

def get_dirs(base_dir):
    '''Gets list of PDOS directories.'''
    pdos_dirs=[]
    for root, dirs, files in os.walk(base_dir):
        if root.endswith("VASP_inputs/PDOS") and 'integrated-pdos.csv' in files:
            pdos_dirs.append(root)
        elif root.endswith("VASP_inputs/PDOS") and "integrated-pdos.csv" not in files:
            print("PDOS calculations haven't been integrated yet.")
    def sort_dirs(data):
        path_list = data.split('/')
        for p in path_list:
            if p.startswith('Modification_'):
                num = p.split('_')[1]
                return int(num)
    pdos_dirs.sort(key=sort_dirs)
    return pdos_dirs

def get_atoms(file):
    '''Determine atome indices'''
    #read file
    atoms = read(file)
    #get formula
    sym = atoms.get_chemical_formula()
    f = Formula(sym)
    atom_counts = f.count()
    #determine number of removed atoms
    if 'Li' in atom_counts.keys():
        li = 18 - atom_counts.get('Li')
    else:
        li = 18
    if 'O' in atom_counts.keys():
        o = 36 - atom_counts.get('O')
    else:
        o = 36
    atom_rem = li + o
    #determine indices
    o_idx = 43 - atom_rem
    m_idxs = [(21- atom_rem), (23- atom_rem), (25 - atom_rem)]
    if li == 18:
        lix = 0
    else:
        lix = 1 - (0.055*li)
    
    return atoms, o_idx, m_idxs, lix

def band_gap(vasprun):
    '''Gets the band gap for the vasprun.xml file.'''
    # Get band structure and band gap
    band_struc = vasprun.get_band_structure()
    band_gap = band_struc.get_band_gap()
    fermi = band_struc.efermi
    cbm = band_struc.get_cbm()['energy']
    vbm = band_struc.get_vbm()['energy']
    return band_gap['energy'],fermi,cbm,vbm

def get_form_en(vasprun):
    '''Computes energy of formation.'''
    # Reference energies in eV/atom
    ref_energies = {
        "O": -9.03 / 2,  # O2 molecule → per atom
        "Li": -1.9072204,
        "Ni": -5.469965403,
        "Mn": -8.998062074,
        "Co": -6.8377063,
        "Fe": -8.243958785,
        "Al": -3.764685413,
    }
    #read vasprun.xml, get final structure, energy & composition
    struc = vasprun.final_structure
    tot_en = vasprun.final_energy
    comp = struc.composition
    
    #get ref energy
    ref_energy = sum([amt * ref_energies[el.symbol] for el, amt in comp.items()])
    #get form energy
    form_en = tot_en - ref_energy
    return form_en

def get_band_center(vasprun,m_idxs,o_idx,cbm):
    '''Gets d_band centers from vasprun.xml'''
    #get structure
    struc = vasprun.final_structure
    all_sites = struc.sites
    #get dos
    dos = vasprun.complete_dos
    #get sites & band centers 
    band_centers = {}
    val_full = 0
    val_occ = 0
    val_unocc = 0
    bw_full = 0
    bw_occ = 0
    for i, site in enumerate(all_sites):
        if i in m_idxs:
            if site.label == 'Al':
                site_list=[site]
                bc = dos.get_band_center(band=OrbitalType(1),sites=site_list)
                bc_occ = dos.get_band_center(band=OrbitalType(1),sites=site_list,erange=(float('-inf'),0))
                bc_unocc = dos.get_band_center(band=OrbitalType(1),sites=site_list,erange=(0,float('inf')))
                band_width = dos.get_band_width(band=OrbitalType(1),sites=site_list)
                occ_bw = dos.get_band_width(band=OrbitalType(1),sites=site_list, erange=(float('-inf'),0))
                band_centers.update({f'{i}_bc_full':bc,f'{i}_bc_occ':bc_occ,f'{i}_bc_unocc':bc_unocc,f'{i}_band_width':band_width, f'{i}_occ_bw':occ_bw})
            else:
                site_list=[site]
                bc = dos.get_band_center(sites=site_list)
                bc_occ = dos.get_band_center(sites=site_list,erange=(float('-inf'),0))
                bc_unocc = dos.get_band_center(sites=site_list,erange=(0,float('inf')))
                band_width = dos.get_band_width(sites=site_list)
                occ_bw = dos.get_band_width(sites=site_list, erange=(float('-inf'),0))
                band_centers.update({f'{i}_bc_full':bc,f'{i}_bc_occ':bc_occ,f'{i}_bc_unocc':bc_unocc,f'{i}_band_width':band_width,f'{i}_occ_bw':occ_bw})
            val_full += bc
            val_occ += bc_occ
            val_unocc += bc_unocc
            bw_full += band_width
            bw_occ += occ_bw
        if i == o_idx:
            site_list=[site]
            bc = dos.get_band_center(band=OrbitalType(1),sites=site_list)
            bc_occ = dos.get_band_center(band=OrbitalType(1),sites=site_list,erange=(float('-inf'),0))
            bc_unocc = dos.get_band_center(band=OrbitalType(1),sites=site_list,erange=(0,float('inf')))
            band_width = dos.get_band_width(band=OrbitalType(1),sites=site_list)
            occ_bw = dos.get_band_width(band=OrbitalType(1),sites=site_list, erange=(float('-inf'),0))
            bc_cbm_diff = cbm - bc
            band_centers.update({'O(p)_bc_full':bc,'O(p)_bc_occ':bc_occ,'O(p)_bc_unocc':bc_unocc, 'O(p)_cbm_diff':bc_cbm_diff,'O(p)_band_width':band_width, 'O(p)_occ_bw':occ_bw})
    
    avg_val_full = val_full/3
    avg_val_occ = val_occ/3
    avg_val_unocc = val_unocc/3
    avg_band_width = bw_full/3
    avg_bw_occ = bw_occ/3
    full_bc_diff = avg_val_full - band_centers['O(p)_bc_full']
    occ_bc_diff = avg_val_occ - band_centers['O(p)_bc_occ']
    avg_bc = pd.Series({'avg_val_full':avg_val_full,'avg_val_occ':avg_val_occ,'avg_val_unocc':avg_val_unocc,'avg_band_width':avg_band_width,'avg_bw_occ':avg_bw_occ,'full_bc_diff':full_bc_diff, 'occ_bc_diff':occ_bc_diff})
    bc_ser = pd.Series(band_centers)
    return bc_ser, avg_bc

def get_eln(atoms, m_idxs):
    '''Gets electronegativity descriptors'''
    # Descriptor table (no d-electrons)
    metal_data = {
        'Li': {'Z': 3,  'chi': 0.98, 'radius': 1.28},
        'Al': {'Z': 13, 'chi': 1.61, 'radius': 1.21},
        'Mn': {'Z': 25, 'chi': 1.55, 'radius': 1.39},
        'Fe': {'Z': 26, 'chi': 1.83, 'radius': 1.32},
        'Co': {'Z': 27, 'chi': 1.88, 'radius': 1.26},
        'Ni': {'Z': 28, 'chi': 1.91, 'radius': 1.24}
    }
    #base variables
    chi_O = 3.44
    eln_data = {}
    eln_sum = 0
    #calculate delta chi
    for idx in m_idxs:
        symbol = atoms[idx].symbol
        props = metal_data[symbol]
        delta_chi = chi_O - props['chi']
        eln_data.update({f'{idx}_chi':delta_chi})
    
    #get string & sum
    for x in eln_data.values():
        eln_sum += float(x)
    #get average
    eln_avg = eln_sum/3
    eln_data.update({'sum_chi':eln_sum,'avg_chi':eln_avg})
    eln = pd.Series(eln_data)
    return eln

def bond_lengths(atoms, o_idx, m_idxs):
    '''Get bond lengths between oxygen and three bonded metals.'''
    bond_lengths = {}
    for i in m_idxs:
        dist = atoms.get_distance(o_idx, i, mic=False)
        bond_lengths.update({f'O_M{i}':dist})
    
    bl_sum = 0
    for i in bond_lengths.values():
        bl_sum += float(i)
    bl_avg = bl_sum/3
    bond_lengths.update({'BL_avg':bl_avg})
    bl_ser = pd.Series(bond_lengths)
    return bl_ser

def int_pdos(energy, up, down):
    """Integrates PDOS in specified windows."""
    #get bottom of integration window
    for x in range(len(energy)):
        if energy[x] >= -8:
            a = x
            break
    #get top of integration window
    for x in range(len(energy)):
        if energy[x] > 0:
            b = x
            break
    
    #split arrays
    els = np.split(energy,[a,b])
    uls = np.split(up,[a,b])
    dls = np.split(down,[a,b])
    e_win = els[1]
    u_win = uls[1]
    d_win = dls[1]
    #integrate
    up_e = simpson(u_win,x=e_win)
    down_e = simpson(d_win, x=e_win)
    tot_e = up_e + np.abs(down_e)
    return tot_e

def t2g_eg_dos(vasprun,m_idxs):
    '''Gets site t2g & e_g projected DOS and integrates.'''
    #get data from vasprun
    struc = vasprun.final_structure
    all_sites = struc.sites
    dos = vasprun.complete_dos
    
    #set up list
    t2g_eg_dict ={}
    al_dict = {}
    #get dos data
    for i, site in enumerate(all_sites):
        if i in m_idxs:
            if site.label == 'Al':
                al_dict.update({f'{i}_t2g':0,f'{i}_eg':0})
            else: 
                bc = dos.get_site_t2g_eg_resolved_dos(site=site)
                t2g = bc['t2g'].as_dict()
                eg = bc['e_g'].as_dict()
                #integrate data
                t2g_en = np.subtract(t2g['energies'],t2g['efermi'])
                t2g_data = t2g['densities']
                eg_data = eg['densities']
                eg_en = np.subtract(eg['energies'],eg['efermi'])
                t2g_tot_e = int_pdos(t2g_en, t2g_data['1'], t2g_data['-1'])
                eg_tot_e = int_pdos(eg_en,eg_data['1'],eg_data['-1'])
                t2g_eg_dict.update({f'{i}_t2g':t2g_tot_e,f'{i}_eg':eg_tot_e})
    
    if len(t2g_eg_dict) < 6:
        t2g_eg_dict.update(al_dict)
    t2g_eg = pd.Series(t2g_eg_dict)
    return t2g_eg
    
def get_pdos_data(pdos_dir,m_idxs):
    '''Gets data from integrated-pdos.csv'''
    #read csv
    if os.path.exists(os.path.join(pdos_dir,'integrated-pdos.csv')): 
        df = pd.read_csv(os.path.join(pdos_dir,'integrated-pdos.csv'))
    else:
        print('PDOS not integrated. Please integrate data before continuing.')
        return
    #if atom index column not in df
    if 'Atom index' not in df.columns:
        elements = []
        idxs = []
        for atom in df['Atom']:
            index = ''
            for char in atom:
                if char.isdigit():
                    index +=f'{char}'
            ele = atom.strip('0123456789')
            elements.append(ele)
            idxs.append(float(index))
        df.insert(1,'Element',elements)
        df.insert(2,'Atom index',idxs)
    
    sel_df = df.query('`Atom index` in @m_idxs')      
    sel_sum = sel_df.sum(numeric_only=True)
    sums = df.sum(numeric_only=True) 
    elements = sel_df['Element']
    atomic_numbers = {
        'Al':13,
        'Mn':25,
        'Fe':26,
        'Co':27,
        'Ni':28
        }
    Z_sum=0
    #get 3Z
    for e in elements:
        if e in atomic_numbers.keys():
            Z_sum += atomic_numbers[f'{e}']
            
    #create series for 3z
    Z = pd.Series(data={'3Z':Z_sum})
    #get # of electrons for LCE
    LCE_elec = {}
    for i in sel_df.index:
        elec = sel_df.at[i,'e_tot']
        idx = sel_df.at[i,'Atom index']
        LCE_elec.update({f'{idx}_elec':elec})
    elec_ser = pd.Series(LCE_elec)
    #drop unnecessary items
    sel_sum =sel_sum.drop(index=['Atom index','e_tot'])
    sums = sums.drop(index='Atom index')
    #reindex
    sel_sum = sel_sum.rename({'OS':'3OS','spin':'3S','H d/p':'3Hdp'})
    sums = sums.rename({'OS':'tot_OS','spin':'tot_S','H d/p':'tot_Hdp'})
    #concatenate pd Series
    pdos_data = pd.concat([sel_sum,Z,sums])
    return pdos_data,elec_ser

def get_ion_e_pol(vasprun,m_idxs):
    '''Gets first ionization energy and polarizability'''
    struc = vasprun.final_structure
    all_sites = struc.sites
    
    pol_dict={
        'Al':{'val':57.8, 'stddev':1.0},
        'Mn':{'val':68, 'stddev':9},
        'Fe':{'val':62, 'stddev':4},
        'Co':{'val':55, 'stddev':4},
        'Ni':{'val':49, 'stddev':3}
        }
    ion_pol_data = {}
    sum_ion_e = 0
    for i,site in enumerate(all_sites):
        if i in m_idxs:
            ele = site.specie
            ion_e = ele.ionization_energy
            sum_ion_e += ion_e
            if site.label in pol_dict.keys():
                pol_data = pol_dict[site.label]
                val = pol_data['val']
                stddev = pol_data['stddev']
                min_pol = val - stddev
                max_pol = val + stddev
            ion_pol_data.update({f'{i}_ion_e':ion_e,f'{i}_min_pol':min_pol,f'{i}_pol':val,f'{i}_max_pol':max_pol})
    avg_ion_e = sum_ion_e/3
    ion_pol_data.update({'avg_ion_e':avg_ion_e})
    ion_pol_ser = pd.Series(ion_pol_data)
    return ion_pol_ser

def get_binary_evac(vasprun,m_idxs):
    '''Gets O vacancy energy from binary metal oxide for each metal species in LCE'''
    struc = vasprun.final_structure
    all_sites = struc.sites
    
    binary_dict={
        'Al':6.91638435,
        'Mn':3.28671184,
        'Fe':3.778409415,
        'Co':2.48314856,
        'Ni':2.02617786
        }
    binary_evac_data = {}
    sum_bin_evac = 0
    for i,site in enumerate(all_sites):
        if i in m_idxs:
            if site.label in binary_dict.keys():
                bin_evac = binary_dict[site.label]
                sum_bin_evac += bin_evac
                binary_evac_data.update({f'{i}_bin_evac':bin_evac})
    avg_bin_evac = sum_bin_evac/3
    binary_evac_data.update({'avg_bin_evac':avg_bin_evac})
    bin_evac_ser = pd.Series(binary_evac_data)
    return bin_evac_ser

def get_std_pot(vasprun,m_idxs):
    '''Gets standard reduction potential for LCE metals. Values are for M^x+ + x*e- -> M(s), from CRC handbook 97th ed.'''
    #get data from vasprun
    struc = vasprun.final_structure
    all_sites = struc.sites
    
    redox_dict = {
        'Al':-1.676,
        'Mn':-1.185,
        'Fe':-0.447,
        'Co':-0.28,
        'Ni':-0.257
        }
    std_redox_data = {}
    sum_std_pot = 0
    for i,site in enumerate(all_sites):
        if i in m_idxs:
            if site.label in redox_dict.keys():
                std_pot = redox_dict[site.label]
                sum_std_pot += std_pot
                std_redox_data.update({f'{i}_std_pot':std_pot})
    avg_std_pot = sum_std_pot/3
    std_redox_data.update({'avg_std_pot':avg_std_pot})
    std_redox_ser = pd.Series(std_redox_data)
    return std_redox_ser
    
def pdos_weights(vasprun,m_idxs):
    '''Gets average intensity of occupied PDOS regions for LCE metals.'''
    #get data from vasprun
    struc = vasprun.final_structure
    all_sites = struc.sites
    dos = vasprun.complete_dos
    
    #set up dicts
    pdos_weights = {}
    
    #get weights
    for i, site in enumerate(all_sites):
        if i in m_idxs:
            #select orbital
            if site.label == 'Al':
                orb = OrbitalType(1)
                lower = -8
            else:
                orb = OrbitalType(2)
                lower = -6
            
            #get site dos
            site_dos = dos.get_site_spd_dos(site=site)
            orb_dos = site_dos[orb]
            energy = orb_dos.energies
            densities = orb_dos.densities
            up = densities[Spin(1)]
            down = densities[Spin(-1)]
            
            #get bounds
            for x in range(len(energy)):
                if energy[x] >= lower:
                    a = x
                    break
            
            for x in range(len(energy)):
                if energy[x] >0:
                    b = x
                    break
            
            #split arrays
            uls = np.split(up,[a,b])
            dls = np.split(down,[a,b])
            #calculate sums & average intensity
            u_sum = np.sum(uls[1])
            d_sum = np.sum(dls[1])
            tot_sum = u_sum + d_sum
            n = len(uls[1])
            avg = tot_sum/n
            #update dict
            pdos_weights.update({f'{i}_avg_intensity':avg})
    
    #avg LCE
    lce_sum = 0
    for i in m_idxs:
        lce_sum += pdos_weights[f'{i}_avg_intensity']
    lce_avg = lce_sum/(len(m_idxs))
    pdos_weights.update({'LCE_avg_intensity':lce_avg})
    
    #create pd series
    pdos_weights_ser = pd.Series(pdos_weights)
    return pdos_weights_ser

def get_wtd_desc(m_idxs,pdos_weights,elec_data,bc_ser):
    '''Gets various weighted descriptors.'''
    wtd_desc ={}
    #get electron weighted descriptors
    sum_bc_o = 0
    sum_bw_o = 0
    tot_e = 0
    for i in m_idxs:
        elec = elec_data[f'{i}_elec']
        tot_e += elec
        sum_bc_o += (bc_ser[f'{i}_bc_occ']* elec)
        sum_bw_o += (bc_ser[f'{i}_occ_bw']* elec)
    wtd_desc.update({'elec_wtd_bc_occ':(sum_bc_o/tot_e),'elec_wtd_bw_occ':(sum_bw_o/tot_e)})
    
    #get intensity weighted descriptors
    sum_bc = 0
    sum_bw = 0
    sum_ints = 0
    for i in m_idxs:
        wt = pdos_weights[f'{i}_avg_intensity']
        sum_ints += wt
        sum_bc += (bc_ser[f'{i}_bc_occ']* wt)
        sum_bw += (bc_ser[f'{i}_occ_bw']* wt)
    wtd_desc.update({'int_wtd_bc_occ':(sum_bc/sum_ints),'int_wtd_bw_occ':(sum_bw/sum_ints)})
    
    wtd_ser = pd.Series(wtd_desc)
    return wtd_ser

def extract_desc(base_dir):
    '''Extract descriptors.'''
    #get directories
    pdos_dirs = get_dirs(base_dir)
    
    if not pdos_dirs:
        print('No PDOS directories found. Exiting...')
        return
    
    #get modifications from ModsCo.txt
    if os.path.exists(os.path.join(base_dir,'ModsCo.txt')):
        mods = read_file(base_dir, 'ModsCo.txt')
        #convert the commas to dashes so the csv won't separate incorrectly
        mods_str = []
        for m in mods:
            ml= m.strip('\n').split(',')
            ms = ''
            for i in ml:
                ms += f'{i}-'
            ms = ms.strip('-')
            mods_str.append(ms)
        mods = mods_str
    else:
        #if no ModsCo.txt file, pulls mod dir names
        mods = []
        for root, dirs, files in os.walk(base_dir):
            if os.path.basename(root).startswith('Modification_'):
                mods.append(os.path.basename(root))
        mods.sort(key=sort_mods)
    
    mod_data_list = []
    for pdos_dir in pdos_dirs:
        for i, mod in enumerate(mods,1):
            if f'Modification_{i}/' in pdos_dir:
                opt_dir = os.path.dirname(pdos_dir)
                #get atoms and indices from CONTCAR
                atoms, o_idx, m_idxs, lix = get_atoms(os.path.join(opt_dir,'CONTCAR'))
                #get integrated pdos data 
                pdos_data, elec_data = get_pdos_data(pdos_dir, m_idxs)
                #get electronegativty data
                eln = get_eln(atoms,m_idxs)
                #get bond lengths
                bl_ser = bond_lengths(atoms, o_idx, m_idxs)
                #get vasprun for form energy, band gap, band center and t2g/eg dos
                #use optimization for form_en & band gap, pdos for band center & t2g/eg 
                opt_vpr = Vasprun(os.path.join(opt_dir,'vasprun.xml'))
                pdos_vpr = Vasprun(os.path.join(pdos_dir,'vasprun.xml'))
                #get formation energy
                form_en = get_form_en(opt_vpr)
                #get band gap & fermi energy
                bg_e,fermi,cbm,vbm = band_gap(pdos_vpr)
                #check cbm
                if cbm == None:
                    dos = pdos_vpr.complete_dos
                    fermi = dos.efermi
                    cbm,vbm = dos.get_cbm_vbm()
                #get band centers
                bc_ser, avg_bc = get_band_center(pdos_vpr, m_idxs,o_idx,cbm)
                #get t2g/eg dos
                t2g_eg = t2g_eg_dos(pdos_vpr, m_idxs)
                #get ionization e and polarizability
                ion_pol_ser = get_ion_e_pol(opt_vpr, m_idxs)
                #get evac from binary oxides
                bin_evac_ser = get_binary_evac(opt_vpr, m_idxs)
                #get std reduction potential
                std_pot_ser = get_std_pot(opt_vpr, m_idxs)
                #get avg intensities
                pdos_weights_ser = pdos_weights(pdos_vpr, m_idxs)
                #get weighted descriptors
                wtd_ser = get_wtd_desc(m_idxs, pdos_weights_ser, elec_data, bc_ser)
                #create pandas series with modification and single value returns
                e_ser = pd.Series(data={'Modification':mod,'E_form':form_en,'E_fermi':fermi,'E_bg':bg_e,'VBM':vbm,'CBM':cbm,'Lix':lix})
                #concatenate all series
                mod_ser = pd.concat([e_ser,pdos_data,bl_ser,eln,bc_ser,t2g_eg,ion_pol_ser,bin_evac_ser,avg_bc,std_pot_ser,pdos_weights_ser,wtd_ser])
                #append series to list
                mod_data_list.append(mod_ser)
    
    #create data frame from mod_data_list
    mod_data = pd.DataFrame(data=mod_data_list)
    #reindex dataframe to use modification
    mod_data = mod_data.set_index('Modification')
    #print data to csv
    mod_data.to_csv(os.path.join(base_dir,'descriptors.csv'))
    print('Descriptors extracted and descriptors.csv created.')
    
